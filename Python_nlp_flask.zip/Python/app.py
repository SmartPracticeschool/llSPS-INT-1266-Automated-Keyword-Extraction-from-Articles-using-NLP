import pandas as pd
from flask import Flask, render_template, request
from keras.models import load_model
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences

app = Flask(__name__)
df = pd.read_csv("Restaurant_Reviews.tsv", delimiter="\t", quoting=3)
x = df["Review"].values


@app.route("/")
def home():
    return render_template("home.html")


@app.route("/predict", methods=["POST"])
def predict():
    if request.method == "POST":
        review = request.form["message"]
        tokenizer = Tokenizer(num_words=100)
        tokenizer.fit_on_texts(x)
        review_seq = tokenizer.texts_to_sequences([review])

        maxlen = 10
        review_seq = pad_sequences(review_seq, padding="post", maxlen=maxlen)

        # load model
        model = load_model("model.hdf5")
        result = model.predict_classes(review_seq)
    return render_template("result.html", prediction=result)


if __name__ == "__main__":
    app.run(debug=True)
